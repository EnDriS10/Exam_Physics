%% C1_2021_2
clear all ; clc ;
figure(178) ;

%% DATOS
dt=1E-2 ; N=2^10-1 ;
dr=1.5E-4 ; p=+0.5 ; dth=4*pi*1E-3 ; q=+0.5 ; L1=[1,0,0,0,0,0,0,0,0,1] ;

%% 2A secuencia [1.75 puntos]
LL=zeros(10,N) ;
LL(:,1)=L1' ;
for n=1:N-1
   LL(1,n+1)=xor(LL(3,n),LL(10,n)) ;
   LL(2:10,n+1)=LL(1:9,n) ;
end
s=LL(10,:) ;

%% 2B TRAYECTORIA[1 punto]
r=zeros(N,1) ; th=zeros(N,1) ; 
r(1)=0 ; th(1)=0 ;
for n=1:N-1
    r(n+1)=r(n)+dr*(1+p*s(n)) ;
    th(n+1)=th(n)+dth*(1+q*(1-s(n))) ;
end
x=r.*cos(th) ; y=r.*sin(th) ;
subplot(2,2,1) ; plot(x,y) ; axis equal ;
title('trayectoria') ; grid on ;
xlabel('posici�n x (m)') ; ylabel('posici�n y (m)') ;

%% 2C POSICI�N Y DISTANCIA AL ORIGEN [0.5 puntos]
t=((0:N-1)*dt)' ;
d=sqrt(x.^2+y.^2) ;
subplot(2,2,2) ; plot(t,x,t,y,t,d) ;
title('posici�n') ; grid on ;
xlabel('tiempo (m)') ; ylabel('posici�n (m)') ;
legend('x','y','distancia al origen') ;

%% 2D VELOCIDAD [0.75 puntos]
vx=mi_derivada(t,x) ; vy=mi_derivada(t,y) ; v=sqrt(vx.^2+vy.^2) ;
subplot(2,2,3) ; plot(t,vx,t,vy,t,v) ;
title('velocidad') ; grid on ;
xlabel('tiempo (m)') ; ylabel('velocidad (m/s)') ;
legend('v_x','v_y','|v|') ;

%% 2E DISTANCIA RECORRIDA [0.5 puntos]
rec=mi_integral_cum(t,v,0) ;
subplot(2,2,2) ; hold on ; plot(t,rec) ; hold off ;
legend('x','y','distancia al origen','d recorrida') ;

%% 2F N�MERO DE UNOS Y CEROS [0.5 PUNTOS]
unos=sum(s==1) ; ceros=sum(s==0) ;
disp(['n�mero de unos = ',num2str(unos),' n�mero de ceros = ',num2str(ceros)]) ;

%% 2G RACHAS [0.25 puntos]
r101=0 ;
for i=1:N-2
   if s(i:i+2)==[1,0,1] r101=r101+1 ;  end
end 
r1001=0 ;
for i=1:N-3
   if s(i:i+3)==[1,0,0,1] r1001=r1001+1 ; end
end 

disp(['n�mero de rachas [101] = ',num2str(r101)]) ;
disp(['n�mero de rachas [1001] = ',num2str(r1001)]) ;
disp(['proporci�n rachas [101]/[1001] = ',num2str(r101/r1001)]) ;

%% FUNCIONES ========================================================
function [dydx]=mi_derivada(x,y)
    dydx=zeros(size(y)) ; 
    dydx(1)=(y(2)-y(1))/(x(2)-x(1)) ;
    dydx(end)=(y(end)-y(end-1))/(x(end)-x(end-1)) ;
    dydx(2:end-1)=(y(3:end)-y(1:end-2))./(x(3:end)-x(1:end-2)) ;
end

function [inty]=mi_integral_cum(x,y,y0)
    inty=zeros(size(y)) ;
    inty(2:end)=cumsum(diff(x).*(y(1:end-1)+y(2:end))/2) ;
    inty=y0+inty ;
end
