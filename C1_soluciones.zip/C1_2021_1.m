%% C1_20201_1
clear all ; clc ;
figure(171) ;

%% DATOS (metros)
a=1.5 ; b=1.0 ; 

%% 1A [1.75 puntos] funci�n de usuario (ver abajo)
%[A,P,B]=Triangle([0 0],[1 0],[1 2]) % test

%% 1B [0.75 puntos] curva param�trica
N=1E3 ; fi=linspace(-pi,0,N) ;
x=a*cos(fi) ; y=-b*sin(fi).*(1+cos(fi)) ;
plot(x,y) ; axis equal ; grid on ;
xlabel('posici�n x (m)') ; ylabel('posici�n y (m)') ;

%% 1C [1.75] �rea y baricentro por ti�ngulos
AT=0 ;
BT=[0 0] ;
for i=1:N-1 
   [A,P,B]=Triangle([0 0],[x(i) y(i)],[x(i+1) y(i+1)]) ; 
   AT=AT+A ; 
   BT=BT+A*B ;
end
BT=BT/AT ; 
hold on ; plot(BT(1),BT(2),'or') ; hold off ;
legend('curva param�trica','baricentro') ;
title('curva param�trica y baricentro') ;
fprintf('coordenadas (x,y) del baricentro (metros) = (%.3f,%.3f)\n',...
    BT(1),BT(2)) ;

%% 1D [0.50 puntos] integral
cumarea=mi_integral_cum(x,y,0) ;
area=cumarea(end) ;
fprintf('�rea tri�ngulos = %.3f m^2\n',AT) ;
fprintf('�rea integral = %.3f m^2\n',area) ;

%% FUNCIONES =========================================================
function [inty]=mi_integral_cum(x,y,y0)
    inty=zeros(size(y)) ;
    inty(2:end)=cumsum(diff(x).*(y(1:end-1)+y(2:end))/2) ;
    inty=inty+y0 ;
end

function [A,P,B]=Triangle(V1,V2,V3) 
    L1=V2-V1 ; L2=V3-V2 ; L3=V1-V3 ;
    if length(V1)==2
        A=0.5*abs(L1(1)*L2(2)-L2(1)*L1(2)) ;
    else
        A=0.5*abs(cross(L1,L2)) ;                
    end 
    P=vecnorm(L1)+vecnorm(L2)+vecnorm(L3) ; 
    B=(V1+V2+V3)/3 ;
end